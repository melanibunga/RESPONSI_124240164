import 'package:flutter/material.dart';

import '../models/character.dart';
import '../services/favorites_store.dart';
import 'detail_screen.dart';
import 'widgets.dart';

class FavoritesScreen extends StatelessWidget {
  const FavoritesScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return ListenableBuilder(
      listenable: FavoritesStore.instance,
      builder: (context, _) {
        final items = FavoritesStore.instance.items;

        if (items.isEmpty) {
          return Center(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                Icon(Icons.favorite_border,
                    size: 64, color: Theme.of(context).colorScheme.outline),
                const SizedBox(height: 12),
                const Text('Belum ada karakter favorit'),
                const SizedBox(height: 4),
                Text(
                  'Tekan ikon hati pada karakter untuk menambahkan',
                  style: TextStyle(
                      color: Theme.of(context).colorScheme.onSurfaceVariant),
                ),
              ],
            ),
          );
        }

        return ListView.builder(
          padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 4),
          itemCount: items.length,
          itemBuilder: (context, i) {
            final Character c = items[i];
            return Dismissible(
              key: ValueKey(c.id),
              direction: DismissDirection.endToStart,
              background: Container(
                margin: const EdgeInsets.symmetric(vertical: 4),
                padding: const EdgeInsets.only(right: 24),
                alignment: Alignment.centerRight,
                decoration: BoxDecoration(
                  color: Colors.redAccent,
                  borderRadius: BorderRadius.circular(12),
                ),
                child: const Icon(Icons.delete, color: Colors.white),
              ),
              onDismissed: (_) async {
                final messenger = ScaffoldMessenger.of(context);
                await FavoritesStore.instance.remove(c.id);
                messenger
                  ..hideCurrentSnackBar()
                  ..showSnackBar(SnackBar(
                    content: Text('${c.name} dihapus dari favorit'),
                    action: SnackBarAction(
                      label: 'UNDO',
                      onPressed: () => FavoritesStore.instance.add(c),
                    ),
                  ));
              },
              child: Card(
                margin: const EdgeInsets.symmetric(vertical: 4),
                child: ListTile(
                  leading: CharacterAvatar(url: c.image),
                  title: Text(c.name),
                  subtitle: StatusBadge(c.status),
                  trailing: const Icon(Icons.chevron_right),
                  onTap: () => Navigator.of(context).push(
                    MaterialPageRoute(
                        builder: (_) => DetailScreen(character: c)),
                  ),
                ),
              ),
            );
          },
        );
      },
    );
  }
}
