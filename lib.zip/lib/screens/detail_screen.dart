import 'package:flutter/material.dart';

import '../models/character.dart';
import '../services/api_service.dart';
import '../services/favorites_store.dart';
import 'widgets.dart';

class DetailScreen extends StatefulWidget {
  final Character character;
  const DetailScreen({super.key, required this.character});

  @override
  State<DetailScreen> createState() => _DetailScreenState();
}

class _DetailScreenState extends State<DetailScreen> {
  late Future<Character> _future;

  @override
  void initState() {
    super.initState();
    _future = ApiService.fetchCharacter(widget.character.id);
  }

  void _retry() {
    setState(() {
      _future = ApiService.fetchCharacter(widget.character.id);
    });
  }

  Future<void> _toggle(Character c) async {
    final added = await FavoritesStore.instance.toggle(c);
    if (!mounted) return;
    ScaffoldMessenger.of(context)
      ..hideCurrentSnackBar()
      ..showSnackBar(SnackBar(
        content: Text(added
            ? '${c.name} ditambahkan ke favorit'
            : '${c.name} dihapus dari favorit'),
      ));
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(widget.character.name),
        actions: [
          ListenableBuilder(
            listenable: FavoritesStore.instance,
            builder: (context, _) {
              final fav =
                  FavoritesStore.instance.isFavorite(widget.character.id);
              return IconButton(
                tooltip: fav ? 'Hapus dari favorit' : 'Tambah ke favorit',
                icon: Icon(
                  fav ? Icons.favorite : Icons.favorite_border,
                  color: fav ? Colors.redAccent : null,
                ),
                onPressed: () => _toggle(widget.character),
              );
            },
          ),
        ],
      ),
      body: FutureBuilder<Character>(
        future: _future,
        builder: (context, snap) {
          if (snap.connectionState != ConnectionState.done) {
            return const Center(child: CircularProgressIndicator());
          }
          if (snap.hasError) {
            return ErrorView(message: snap.error.toString(), onRetry: _retry);
          }
          return _content(snap.data!);
        },
      ),
    );
  }

  Widget _content(Character c) {
    return SingleChildScrollView(
      padding: const EdgeInsets.all(20),
      child: Column(
        children: [
          ClipRRect(
            borderRadius: BorderRadius.circular(24),
            child: Image.network(
              c.image,
              width: 260,
              height: 260,
              fit: BoxFit.cover,
              errorBuilder: (_, __, ___) => const SizedBox(
                  width: 260, height: 260, child: Icon(Icons.broken_image, size: 64)),
            ),
          ),
          const SizedBox(height: 16),
          Text(
            c.name,
            textAlign: TextAlign.center,
            style: Theme.of(context)
                .textTheme
                .headlineSmall
                ?.copyWith(fontWeight: FontWeight.bold),
          ),
          const SizedBox(height: 20),
          Card(
            child: Column(
              children: [
                _row(Icons.monitor_heart_outlined, 'Status', StatusBadge(c.status)),
                _row(Icons.pets_outlined, 'Species', Text(c.species)),
                _row(Icons.wc, 'Gender', Text(c.gender)),
                _row(Icons.public, 'Origin', Text(c.origin)),
                _row(Icons.place_outlined, 'Location', Text(c.location)),
              ],
            ),
          ),
          const SizedBox(height: 20),
          ListenableBuilder(
            listenable: FavoritesStore.instance,
            builder: (context, _) {
              final fav = FavoritesStore.instance.isFavorite(c.id);
              return SizedBox(
                width: double.infinity,
                child: FilledButton.icon(
                  style: FilledButton.styleFrom(
                    padding: const EdgeInsets.symmetric(vertical: 16),
                  ),
                  onPressed: () => _toggle(c),
                  icon: Icon(fav ? Icons.favorite : Icons.favorite_border),
                  label: Text(fav ? 'Hapus dari Favorit' : 'Tambah ke Favorit'),
                ),
              );
            },
          ),
        ],
      ),
    );
  }

  Widget _row(IconData icon, String label, Widget value) {
    return ListTile(
      leading: Icon(icon),
      title: Text(label,
          style: TextStyle(color: Theme.of(context).colorScheme.onSurfaceVariant)),
      trailing: ConstrainedBox(
        constraints: const BoxConstraints(maxWidth: 180),
        child: DefaultTextStyle.merge(
          textAlign: TextAlign.right,
          style: const TextStyle(fontWeight: FontWeight.w600),
          child: value,
        ),
      ),
    );
  }
}
