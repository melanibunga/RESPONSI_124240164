class Character {
  final int id;
  final String name;
  final String status;
  final String species;
  final String gender;
  final String origin;
  final String location;
  final String image;

  const Character({
    required this.id,
    required this.name,
    required this.status,
    required this.species,
    required this.gender,
    required this.origin,
    required this.location,
    required this.image,
  });

  factory Character.fromJson(Map<String, dynamic> json) {
    return Character(
      id: json['id'] as int,
      name: json['name'] as String? ?? '-',
      status: json['status'] as String? ?? 'unknown',
      species: json['species'] as String? ?? '-',
      gender: json['gender'] as String? ?? '-',
      // dari API: origin & location berupa object {name, url}.
      // dari penyimpanan lokal: sudah berupa String.
      origin: json['origin'] is Map
          ? (json['origin']['name'] as String? ?? '-')
          : (json['origin'] as String? ?? '-'),
      location: json['location'] is Map
          ? (json['location']['name'] as String? ?? '-')
          : (json['location'] as String? ?? '-'),
      image: json['image'] as String? ?? '',
    );
  }

  Map<String, dynamic> toJson() => {
        'id': id,
        'name': name,
        'status': status,
        'species': species,
        'gender': gender,
        'origin': origin,
        'location': location,
        'image': image,
      };
}
